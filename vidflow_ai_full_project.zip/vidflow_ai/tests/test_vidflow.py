"""Comprehensive automated test suite for VidFlow AI covering all 13 mandatory test categories."""

import io
import os
import shutil
import subprocess
import tempfile
import unittest
from typing import Dict, Any, Optional
from PIL import Image
from fastapi.testclient import TestClient

from app.config import SUPPORTED_MODELS
from app.database import Database
from app.storage import MediaStorage, StorageError
from app.video_provider import ReplicateVideoProvider, VideoProviderError
from app.stitcher import ScenePlanner, VideoStitcher
from app.worker import VideoJobWorker
from app.main import create_app


def generate_real_test_mp4(output_path: str, duration_sec: float = 2.0, width: int = 320, height: int = 240, color: str = "purple") -> str:
    """Use real FFmpeg lavfi filter to synthesize a valid H.264 MP4 video clip for deterministic testing."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    cmd = [
        "ffmpeg",
        "-y",
        "-f",
        "lavfi",
        "-i",
        f"color=c={color}:s={width}x{height}:r=24:d={duration_sec}",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-pix_fmt",
        "yuv420p",
        output_path,
    ]
    subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=True)
    return output_path


def generate_test_image_bytes(fmt: str = "PNG", width: int = 256, height: int = 256) -> bytes:
    """Create a valid in-memory image (JPEG, PNG, or WEBP) using Pillow."""
    img = Image.new("RGB", (width, height), color=(124, 58, 237))
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return buf.getvalue()


class MockSuccessVideoProvider(ReplicateVideoProvider):
    """Mock provider that simulates Replicate API lifecycle and produces real FFmpeg MP4 segments."""

    def __init__(self, temp_dir: str, segment_duration: float = 5.0) -> None:
        super().__init__(api_token="r8_mock_test_token_12345")
        self.temp_dir = temp_dir
        self.segment_duration = segment_duration
        self.created_predictions: list[Dict[str, Any]] = []
        self.fail_on_call: Optional[int] = None
        self.timeout_on_wait: bool = False

    def create_prediction(
        self,
        model_id: str,
        prompt: str,
        aspect_ratio: str = "9:16",
        segment_duration: int = 5,
        image_path: Optional[str] = None,
        version: Optional[str] = None,
    ) -> Dict[str, Any]:
        self.verify_credentials()
        payload = self.build_model_input_payload(
            model_id=model_id,
            prompt=prompt,
            aspect_ratio=aspect_ratio,
            segment_duration=segment_duration,
            image_path=image_path,
        )
        call_idx = len(self.created_predictions)
        if self.fail_on_call is not None and call_idx == self.fail_on_call:
            raise VideoProviderError("שגיאת ספק AI מדומה (Simulated Provider Failure 500).")

        pred_id = f"pred_mock_{call_idx + 1:03d}"
        rec = {
            "id": pred_id,
            "status": "starting",
            "model_id": model_id,
            "input": payload,
            "target_duration": float(segment_duration),
        }
        self.created_predictions.append(rec)
        return rec

    def wait_for_prediction(
        self,
        prediction_id: str,
        timeout_seconds: Optional[int] = None,
        poll_interval: Optional[float] = None,
    ) -> Dict[str, Any]:
        if self.timeout_on_wait:
            raise VideoProviderError("תם הזמן הקצוב להמתנה לסיום יצירת הווידאו (Simulated Timeout).")
        return {
            "id": prediction_id,
            "status": "succeeded",
            "output": f"https://mock.replicate.delivery/{prediction_id}.mp4",
        }

    def download_video_to_path(self, video_url: str, destination_path: str) -> str:
        # Generate a real valid MP4 file using FFmpeg at destination_path
        return generate_real_test_mp4(destination_path, duration_sec=self.segment_duration, width=360, height=640)


class VidFlowAITestSuite(unittest.TestCase):
    """Tests all 13 mandatory requirements for VidFlow AI."""

    def setUp(self) -> None:
        self.tmp_dir = tempfile.mkdtemp(prefix="vidflow_test_")
        self.db_path = os.path.join(self.tmp_dir, "test_vidflow.db")
        self.storage_dir = os.path.join(self.tmp_dir, "storage")
        self.db = Database(database_url=f"sqlite:///{self.db_path}")
        self.storage = MediaStorage(base_dir=self.storage_dir)
        self.provider = MockSuccessVideoProvider(temp_dir=self.tmp_dir, segment_duration=5.0)
        self.app = create_app(
            db=self.db,
            storage=self.storage,
            provider=self.provider,
            start_worker=False,
        )
        self.client = TestClient(self.app)
        self.user_headers = {"X-VidFlow-Session": "test_user_alpha"}

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    # 1. Health Endpoint Check
    def test_01_health_endpoint(self) -> None:
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["status"], "ok")
        self.assertEqual(data["database"], "connected")
        self.assertTrue(data["ffmpeg_available"])
        self.assertFalse(data["credits_system_enabled"])
        self.assertFalse(data["social_publishing_enabled"])

    # 2. Job Creation (fast return as queued) -> Background Processing -> Status Updates -> Saving Video File
    def test_02_create_job_and_status_lifecycle_and_video_saving(self) -> None:
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "צור סרטון קולנועי של תות אדום עם פנים אנושיות בחדר חשוך",
                "mode": "text_to_video",
                "model_id": "minimax/video-01",
                "requested_duration": "5",
                "aspect_ratio": "9:16",
                "style": "cinematic",
            },
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 201)
        initial_job = resp.json()
        job_id = initial_job["id"]
        self.assertEqual(initial_job["status"], "queued")

        # Now fetch job details after background task completed
        get_resp = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers)
        self.assertEqual(get_resp.status_code, 200)
        job = get_resp.json()
        self.assertEqual(job["status"], "succeeded")
        self.assertEqual(job["progress_percent"], 100)
        self.assertIsNotNone(job["output_video_key"])
        self.assertTrue(self.storage.exists(job["output_video_key"]))
        self.assertGreaterEqual(float(job["actual_duration"]), 4.5)

    # 3. Missing or Invalid Prompt Validation
    def test_03_missing_or_invalid_prompt_rejected(self) -> None:
        # Empty prompt
        r1 = self.client.post(
            "/api/generate",
            data={"prompt": "   ", "mode": "text_to_video"},
            headers=self.user_headers,
        )
        self.assertIn(r1.status_code, (400, 422))

        # Too short prompt (2 chars)
        r2 = self.client.post(
            "/api/generate",
            data={"prompt": "אב", "mode": "text_to_video"},
            headers=self.user_headers,
        )
        self.assertIn(r2.status_code, (400, 422))

    # 4. Image Upload (Valid Image-to-Video, Invalid File Rejection, Unsupported Model Rejection)
    def test_04_image_upload_and_validation(self) -> None:
        valid_png = generate_test_image_bytes("PNG", 300, 300)
        # Valid image with supporting model (minimax/video-01)
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "הנפש את התמונה בעדינות עם תנועת מצלמה איטית",
                "mode": "image_to_video",
                "model_id": "minimax/video-01",
                "requested_duration": "5",
                "aspect_ratio": "9:16",
                "style": "realistic",
            },
            files={"image": ("sample.png", valid_png, "image/png")},
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 201)
        job = resp.json()
        self.assertEqual(job["mode"], "image_to_video")
        self.assertIsNotNone(job["input_image_key"])
        # Verify the provider received the model-specific image field (`first_frame_image`)
        last_pred = self.provider.created_predictions[-1]
        self.assertIn("first_frame_image", last_pred["input"])
        self.assertTrue(last_pred["input"]["first_frame_image"].startswith("data:image/png;base64,"))

        # Malicious / corrupted non-image file must be rejected
        bad_resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "הנפש את התמונה",
                "mode": "image_to_video",
                "model_id": "minimax/video-01",
            },
            files={"image": ("exploit.jpg", b"not-an-image-script-payload", "image/jpeg")},
            headers=self.user_headers,
        )
        self.assertEqual(bad_resp.status_code, 400)

        # Model that does NOT support Image-to-Video (`wan-video/wan-2.1-t2v-480p`) must reject image mode
        unsupported_resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "הנפש את התמונה",
                "mode": "image_to_video",
                "model_id": "wan-video/wan-2.1-t2v-480p",
            },
            files={"image": ("sample.png", valid_png, "image/png")},
            headers=self.user_headers,
        )
        self.assertEqual(unsupported_resp.status_code, 400)

    # 5. AI Provider Error Handling & Segment Retry
    def test_05_provider_error_handling_and_retry(self) -> None:
        self.provider.fail_on_call = 0
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "סרטון בדיקה לטיפול בשגיאת ספק",
                "mode": "text_to_video",
                "model_id": "luma/ray-2-720p",
                "requested_duration": "5",
                "aspect_ratio": "16:9",
            },
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 201)
        job_id = resp.json()["id"]

        failed_job = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers).json()
        self.assertEqual(failed_job["status"], "failed")
        self.assertIn("Simulated Provider Failure", failed_job["error_message"])

        # Now clear the failure condition and test retry endpoint
        self.provider.fail_on_call = None
        retry_resp = self.client.post(f"/api/jobs/{job_id}/retry", headers=self.user_headers)
        self.assertEqual(retry_resp.status_code, 200)

        recovered_job = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers).json()
        self.assertEqual(recovered_job["status"], "succeeded")
        self.assertIsNone(recovered_job["error_message"])

    # 6. Multi-Segment FFmpeg Stitching & Final Duration Verification (Up to 60s)
    def test_06_multi_segment_ffmpeg_stitching_and_duration(self) -> None:
        # Test 15s request on a 5s-per-segment model -> 3 segments stitched via FFmpeg
        self.provider.segment_duration = 5.0
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "סרטון רב-סצנות של מסע בחלל עם מעברים חלקים",
                "mode": "text_to_video",
                "model_id": "luma/ray-2-720p",
                "requested_duration": "15",
                "aspect_ratio": "16:9",
                "style": "fantasy",
            },
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 201)
        job_id = resp.json()["id"]

        job = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers).json()
        self.assertEqual(job["status"], "succeeded")
        self.assertEqual(job["segment_count"], 3)
        self.assertEqual(job["completed_segments"], 3)
        self.assertAlmostEqual(float(job["actual_duration"]), 15.0, delta=0.8)

        # Also verify ScenePlanner produces 10 segments for a 60-second request on a 6s model
        planner = ScenePlanner()
        plan_60 = planner.plan_segments(
            prompt="סרטון תדמית באורך דקה שלמה",
            requested_duration=60,
            model_id="minimax/video-01",
            style="commercial",
            aspect_ratio="9:16",
        )
        self.assertEqual(len(plan_60), 10)
        self.assertAlmostEqual(sum(s["target_duration"] for s in plan_60), 60.0, delta=0.1)

    # 7. Video Download & User Isolation Security
    def test_07_video_download_and_user_isolation(self) -> None:
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "סרטון לבדיקת הורדה ובידוד משתמשים",
                "mode": "text_to_video",
                "model_id": "minimax/video-01",
                "requested_duration": "5",
                "aspect_ratio": "1:1",
            },
            headers=self.user_headers,
        )
        job_id = resp.json()["id"]

        # Owner can download video
        dl_resp = self.client.get(f"/api/jobs/{job_id}/video?download=1", headers=self.user_headers)
        self.assertEqual(dl_resp.status_code, 200)
        self.assertEqual(dl_resp.headers["content-type"], "video/mp4")
        self.assertIn("attachment", dl_resp.headers.get("content-disposition", ""))
        self.assertGreater(len(dl_resp.content), 1000)

        # Different user cannot access or download private job by job_id alone
        other_user_headers = {"X-VidFlow-Session": "test_user_intruder"}
        forbidden_get = self.client.get(f"/api/jobs/{job_id}", headers=other_user_headers)
        self.assertEqual(forbidden_get.status_code, 404)
        forbidden_dl = self.client.get(f"/api/jobs/{job_id}/video", headers=other_user_headers)
        self.assertEqual(forbidden_dl.status_code, 404)

    # 8. Job Deletion & Storage Cleanup
    def test_08_delete_job_and_cleanup_files(self) -> None:
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "סרטון לבדיקת מחיקה מלאה",
                "mode": "text_to_video",
                "model_id": "minimax/video-01",
                "requested_duration": "5",
            },
            headers=self.user_headers,
        )
        job_id = resp.json()["id"]
        job = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers).json()
        video_key = job["output_video_key"]
        self.assertTrue(self.storage.exists(video_key))

        del_resp = self.client.delete(f"/api/jobs/{job_id}", headers=self.user_headers)
        self.assertEqual(del_resp.status_code, 200)
        self.assertFalse(self.storage.exists(video_key))

        get_after = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers)
        self.assertEqual(get_after.status_code, 404)

    # 9. Missing Environment Variables Check (Unconfigured Provider)
    def test_09_missing_provider_env_var_rejected_clearly(self) -> None:
        unconfigured_provider = ReplicateVideoProvider(api_token="")
        app_no_key = create_app(
            db=self.db,
            storage=self.storage,
            provider=unconfigured_provider,
            start_worker=False,
        )
        client_no_key = TestClient(app_no_key)
        resp = client_no_key.post(
            "/api/generate",
            data={"prompt": "ניסיון יצירה ללא מפתח API מוגדר", "mode": "text_to_video"},
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 503)
        self.assertIn("REPLICATE_API_TOKEN", resp.json()["detail"])

    # 10. Provider Timeout Handling
    def test_10_provider_timeout_handling(self) -> None:
        self.provider.timeout_on_wait = True
        resp = self.client.post(
            "/api/generate",
            data={
                "prompt": "בדיקת טיפול ב-Timeout מול ספק ה-AI",
                "mode": "text_to_video",
                "model_id": "minimax/video-01",
                "requested_duration": "5",
            },
            headers=self.user_headers,
        )
        self.assertEqual(resp.status_code, 201)
        job_id = resp.json()["id"]

        job = self.client.get(f"/api/jobs/{job_id}", headers=self.user_headers).json()
        self.assertEqual(job["status"], "failed")
        self.assertIn("Timeout", job["error_message"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

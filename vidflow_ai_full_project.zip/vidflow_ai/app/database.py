"""Database management layer supporting SQLite (local development) and PostgreSQL (production on Render)."""

import os
import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse

from app.config import get_settings


def utc_now_iso() -> str:
    """Return current UTC timestamp in ISO-8601 format."""
    return datetime.now(timezone.utc).isoformat()


class Database:
    """Unified database adapter supporting SQLite and PostgreSQL (psycopg2)."""

    def __init__(self, database_url: Optional[str] = None) -> None:
        settings = get_settings()
        self.database_url = database_url or settings.database_url
        self.is_postgres = self.database_url.startswith(("postgres://", "postgresql://"))
        self._sqlite_path = self._resolve_sqlite_path(self.database_url)
        self.init_db()

    @staticmethod
    def _resolve_sqlite_path(db_url: str) -> str:
        if db_url.startswith("sqlite:///"):
            path = db_url[len("sqlite:///"):]
            return path or "./vidflow.db"
        return "./vidflow.db"

    def _get_connection(self):
        if self.is_postgres:
            import psycopg2
            import psycopg2.extras
            conn = psycopg2.connect(self.database_url)
            return conn
        else:
            parent_dir = os.path.dirname(os.path.abspath(self._sqlite_path))
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)
            conn = sqlite3.connect(self._sqlite_path, timeout=30.0, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON;")
            return conn

    def _placeholder(self) -> str:
        return "%s" if self.is_postgres else "?"

    def _execute(self, query: str, params: tuple = (), fetch: str = "none") -> Any:
        p = self._placeholder()
        sql = query.replace("?", p) if self.is_postgres else query
        conn = self._get_connection()
        try:
            if self.is_postgres:
                import psycopg2.extras
                cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            else:
                cur = conn.cursor()
            cur.execute(sql, params)
            result = None
            if fetch == "one":
                row = cur.fetchone()
                result = dict(row) if row else None
            elif fetch == "all":
                rows = cur.fetchall()
                result = [dict(r) for r in rows]
            conn.commit()
            return result
        finally:
            conn.close()

    def init_db(self) -> None:
        """Create video_jobs and job_segments tables if they do not exist."""
        jobs_table_sql = """
        CREATE TABLE IF NOT EXISTS video_jobs (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            prompt TEXT NOT NULL,
            enhanced_prompt TEXT,
            mode TEXT NOT NULL DEFAULT 'text_to_video',
            model_id TEXT NOT NULL,
            style TEXT NOT NULL DEFAULT 'cinematic',
            custom_style_prompt TEXT,
            aspect_ratio TEXT NOT NULL DEFAULT '9:16',
            requested_duration INTEGER NOT NULL DEFAULT 5,
            actual_duration REAL,
            status TEXT NOT NULL DEFAULT 'queued',
            progress_percent INTEGER NOT NULL DEFAULT 0,
            status_message_he TEXT NOT NULL DEFAULT 'ממתין בתור ליצירה...',
            provider_name TEXT NOT NULL DEFAULT 'replicate',
            provider_job_id TEXT,
            input_image_key TEXT,
            output_video_key TEXT,
            thumbnail_key TEXT,
            error_message TEXT,
            segment_count INTEGER NOT NULL DEFAULT 1,
            completed_segments INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            completed_at TEXT
        );
        """
        segments_table_sql = """
        CREATE TABLE IF NOT EXISTS job_segments (
            id TEXT PRIMARY KEY,
            job_id TEXT NOT NULL,
            segment_index INTEGER NOT NULL,
            total_segments INTEGER NOT NULL,
            scene_prompt TEXT NOT NULL,
            target_duration REAL NOT NULL,
            actual_duration REAL,
            status TEXT NOT NULL DEFAULT 'pending',
            provider_prediction_id TEXT,
            storage_key TEXT,
            error_message TEXT,
            retry_count INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (job_id) REFERENCES video_jobs(id) ON DELETE CASCADE
        );
        """
        self._execute(jobs_table_sql)
        self._execute(segments_table_sql)

    def check_health(self) -> bool:
        """Verify database connectivity."""
        try:
            res = self._execute("SELECT 1 AS ok", fetch="one")
            return bool(res and res.get("ok") == 1)
        except Exception:
            return False

    def create_job(
        self,
        user_id: str,
        prompt: str,
        enhanced_prompt: str,
        mode: str,
        model_id: str,
        style: str,
        custom_style_prompt: Optional[str],
        aspect_ratio: str,
        requested_duration: int,
        provider_name: str,
        input_image_key: Optional[str] = None,
        segment_count: int = 1,
        job_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        jid = job_id or f"job_{uuid.uuid4().hex[:16]}"
        now = utc_now_iso()
        sql = """
        INSERT INTO video_jobs (
            id, user_id, prompt, enhanced_prompt, mode, model_id, style,
            custom_style_prompt, aspect_ratio, requested_duration, status,
            progress_percent, status_message_he, provider_name, input_image_key,
            segment_count, completed_segments, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        self._execute(
            sql,
            (
                jid,
                user_id,
                prompt,
                enhanced_prompt,
                mode,
                model_id,
                style,
                custom_style_prompt,
                aspect_ratio,
                requested_duration,
                "queued",
                0,
                "המשימה התקבלה וממתינה בתור...",
                provider_name,
                input_image_key,
                segment_count,
                0,
                now,
                now,
            ),
        )
        return self.get_job(jid, user_id=user_id)  # type: ignore

    def create_segment(
        self,
        job_id: str,
        segment_index: int,
        total_segments: int,
        scene_prompt: str,
        target_duration: float,
    ) -> Dict[str, Any]:
        sid = f"seg_{uuid.uuid4().hex[:16]}"
        now = utc_now_iso()
        sql = """
        INSERT INTO job_segments (
            id, job_id, segment_index, total_segments, scene_prompt,
            target_duration, status, retry_count, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        self._execute(
            sql,
            (
                sid,
                job_id,
                segment_index,
                total_segments,
                scene_prompt,
                target_duration,
                "pending",
                0,
                now,
                now,
            ),
        )
        return self.get_segment(sid)  # type: ignore

    def get_segment(self, segment_id: str) -> Optional[Dict[str, Any]]:
        return self._execute("SELECT * FROM job_segments WHERE id = ?", (segment_id,), fetch="one")

    def get_job_segments(self, job_id: str) -> List[Dict[str, Any]]:
        return self._execute(
            "SELECT * FROM job_segments WHERE job_id = ? ORDER BY segment_index ASC",
            (job_id,),
            fetch="all",
        ) or []

    def update_segment(self, segment_id: str, **fields: Any) -> Optional[Dict[str, Any]]:
        if not fields:
            return self.get_segment(segment_id)
        fields["updated_at"] = utc_now_iso()
        cols = ", ".join(f"{k} = ?" for k in fields.keys())
        vals = tuple(fields.values()) + (segment_id,)
        self._execute(f"UPDATE job_segments SET {cols} WHERE id = ?", vals)
        return self.get_segment(segment_id)

    def get_job(self, job_id: str, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if user_id:
            job = self._execute(
                "SELECT * FROM video_jobs WHERE id = ? AND user_id = ?",
                (job_id, user_id),
                fetch="one",
            )
        else:
            job = self._execute("SELECT * FROM video_jobs WHERE id = ?", (job_id,), fetch="one")
        if not job:
            return None
        job["segments"] = self.get_job_segments(job_id)
        return job

    def list_jobs(self, user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        jobs = self._execute(
            "SELECT * FROM video_jobs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit),
            fetch="all",
        ) or []
        for job in jobs:
            job["segments"] = self.get_job_segments(job["id"])
        return jobs

    def list_recoverable_jobs(self) -> List[Dict[str, Any]]:
        """Return jobs in queued, processing, or stitching state for worker recovery on server restart."""
        return self._execute(
            "SELECT * FROM video_jobs WHERE status IN ('queued', 'processing', 'stitching') ORDER BY created_at ASC",
            (),
            fetch="all",
        ) or []

    def update_job(self, job_id: str, **fields: Any) -> Optional[Dict[str, Any]]:
        if not fields:
            return self.get_job(job_id)
        fields["updated_at"] = utc_now_iso()
        cols = ", ".join(f"{k} = ?" for k in fields.keys())
        vals = tuple(fields.values()) + (job_id,)
        self._execute(f"UPDATE video_jobs SET {cols} WHERE id = ?", vals)
        return self.get_job(job_id)

    def delete_job(self, job_id: str, user_id: str) -> bool:
        existing = self.get_job(job_id, user_id=user_id)
        if not existing:
            return False
        self._execute("DELETE FROM job_segments WHERE job_id = ?", (job_id,))
        self._execute("DELETE FROM video_jobs WHERE id = ? AND user_id = ?", (job_id, user_id))
        return True

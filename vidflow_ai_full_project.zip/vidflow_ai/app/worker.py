"""Durable background worker and task processor for VidFlow AI."""

import logging
import os
import tempfile
import threading
import time
from typing import Optional, List

from app.config import get_settings
from app.database import Database, utc_now_iso
from app.storage import MediaStorage, StorageError
from app.video_provider import ReplicateVideoProvider, VideoProviderError
from app.stitcher import ScenePlanner, VideoStitcher, StitcherError

logger = logging.getLogger("vidflow.worker")


class VideoJobWorker:
    """Processes video generation jobs asynchronously with database durability and crash recovery."""

    def __init__(
        self,
        db: Optional[Database] = None,
        storage: Optional[MediaStorage] = None,
        provider: Optional[ReplicateVideoProvider] = None,
    ) -> None:
        self.settings = get_settings()
        self.db = db or Database()
        self.storage = storage or MediaStorage()
        self.provider = provider or ReplicateVideoProvider()
        self.planner = ScenePlanner()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def process_job_sync(self, job_id: str) -> None:
        """Execute a single video generation job end-to-end (supports resume after worker restart or failed segment retry)."""
        job = self.db.get_job(job_id)
        if not job:
            return
        if job["status"] in ("succeeded", "canceled"):
            return

        try:
            # 1. Verify provider credentials upfront
            self.provider.verify_credentials()

            # 2. Ensure scene segments exist in database
            segments = self.db.get_job_segments(job_id)
            if not segments:
                self.db.update_job(
                    job_id,
                    status="processing",
                    progress_percent=5,
                    status_message_he="מכינים את הסצנות...",
                    error_message=None,
                )
                planned = self.planner.plan_segments(
                    prompt=job["prompt"],
                    requested_duration=int(job["requested_duration"]),
                    model_id=job["model_id"],
                    style=job["style"],
                    custom_style_prompt=job.get("custom_style_prompt"),
                    aspect_ratio=job["aspect_ratio"],
                )
                for p_seg in planned:
                    self.db.create_segment(
                        job_id=job_id,
                        segment_index=p_seg["segment_index"],
                        total_segments=p_seg["total_segments"],
                        scene_prompt=p_seg["scene_prompt"],
                        target_duration=p_seg["target_duration"],
                    )
                segments = self.db.get_job_segments(job_id)
                self.db.update_job(job_id, segment_count=len(segments))

            total_segs = len(segments)
            input_image_path: Optional[str] = None
            if job.get("mode") == "image_to_video" and job.get("input_image_key"):
                input_image_path = self.storage.get_local_path(job["input_image_key"])
                if not os.path.exists(input_image_path):
                    raise VideoProviderError("קובץ תמונת המקור לא נמצא באחסון.")

            segment_local_paths: List[str] = []

            # 3. Process each segment sequentially (skipping already succeeded segments on retry/recovery)
            for idx, seg in enumerate(segments):
                # Check if job was canceled while running
                fresh_job = self.db.get_job(job_id)
                if fresh_job and fresh_job["status"] == "canceled":
                    return

                seg_id = seg["id"]
                if seg["status"] == "succeeded" and seg.get("storage_key") and self.storage.exists(seg["storage_key"]):
                    segment_local_paths.append(self.storage.get_local_path(seg["storage_key"]))
                    continue

                base_progress = int(10 + (idx / total_segs) * 70)
                msg = (
                    "יוצרים את הסרטון..."
                    if total_segs == 1
                    else f"יוצרים את הסרטון (סצנה {idx + 1} מתוך {total_segs})..."
                )
                self.db.update_job(
                    job_id,
                    status="processing",
                    progress_percent=base_progress,
                    status_message_he=msg,
                    error_message=None,
                )
                self.db.update_segment(seg_id, status="processing", error_message=None)

                try:
                    # Reuse existing prediction ID if worker restarted mid-prediction, otherwise create new
                    pred_id = seg.get("provider_prediction_id")
                    if not pred_id:
                        pred_data = self.provider.create_prediction(
                            model_id=job["model_id"],
                            prompt=seg["scene_prompt"],
                            aspect_ratio=job["aspect_ratio"],
                            segment_duration=int(round(seg["target_duration"])),
                            image_path=input_image_path if idx == 0 else None,
                        )
                        pred_id = pred_data["id"]
                        self.db.update_segment(seg_id, provider_prediction_id=pred_id)
                        if idx == 0:
                            self.db.update_job(job_id, provider_job_id=pred_id)

                    completed_pred = self.provider.wait_for_prediction(pred_id)
                    video_url = self.provider.extract_output_url(completed_pred)

                    seg_storage_key = f"segments/{job_id}_seg_{idx:03d}.mp4"
                    seg_dest_path = self.storage.get_local_path(seg_storage_key)
                    self.provider.download_video_to_path(video_url, seg_dest_path)

                    # Validate downloaded segment file before marking segment succeeded
                    seg_meta = MediaStorage.inspect_video_file(seg_dest_path)
                    self.storage.save_file(seg_storage_key, seg_dest_path, content_type="video/mp4")

                    self.db.update_segment(
                        seg_id,
                        status="succeeded",
                        storage_key=seg_storage_key,
                        actual_duration=seg_meta["duration"],
                        error_message=None,
                    )
                    segment_local_paths.append(seg_dest_path)
                    self.db.update_job(job_id, completed_segments=idx + 1)

                except Exception as seg_exc:
                    self.db.update_segment(
                        seg_id,
                        status="failed",
                        error_message=str(seg_exc),
                        retry_count=int(seg.get("retry_count", 0)) + 1,
                    )
                    raise VideoProviderError(
                        f"כשל ביצירת סצנה {idx + 1} מתוך {total_segs}: {seg_exc}"
                    ) from seg_exc

            # 4. Stitch / normalize segments into final durable MP4
            self.db.update_job(
                job_id,
                status="stitching",
                progress_percent=85,
                status_message_he="מחברים את הקטעים ומעבדים את הווידאו הסופי..." if total_segs > 1 else "בודקים ושומרים את קובץ הווידאו...",
            )

            final_key = f"videos/{job_id}.mp4"
            final_local_path = self.storage.get_local_path(final_key)

            final_meta = VideoStitcher.stitch_segments(
                segment_paths=segment_local_paths,
                output_path=final_local_path,
                aspect_ratio=job["aspect_ratio"],
                target_total_duration=float(job["requested_duration"]),
            )

            # Save final verified MP4 to durable storage (S3 + local)
            self.storage.save_file(final_key, final_local_path, content_type="video/mp4")

            # Verify final stored video exists and is valid BEFORE marking job as succeeded
            verified_meta = MediaStorage.inspect_video_file(final_local_path)
            if not self.storage.exists(final_key):
                raise StorageError("שמירת קובץ הווידאו הסופי באחסון נכשלה.")

            self.db.update_job(
                job_id,
                status="succeeded",
                progress_percent=100,
                status_message_he="הסרטון מוכן לצפייה ולהורדה!",
                output_video_key=final_key,
                actual_duration=verified_meta["duration"],
                completed_segments=total_segs,
                error_message=None,
                completed_at=utc_now_iso(),
            )

        except Exception as exc:
            logger.error("Job %s failed: %s", job_id, exc)
            self.db.update_job(
                job_id,
                status="failed",
                status_message_he="יצירת הסרטון נכשלה.",
                error_message=str(exc),
            )

    def run_once(self) -> int:
        """Find all recoverable/queued jobs and process them. Returns number of jobs processed."""
        jobs = self.db.list_recoverable_jobs()
        count = 0
        for job in jobs:
            if self._stop_event.is_set():
                break
            self.process_job_sync(job["id"])
            count += 1
        return count

    def start_background_loop(self, poll_seconds: float = 1.5) -> None:
        """Start daemon worker loop in background thread for single-instance deployment."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()

        def _loop() -> None:
            while not self._stop_event.is_set():
                try:
                    self.run_once()
                except Exception as exc:
                    logger.error("Background worker error: %s", exc)
                self._stop_event.wait(poll_seconds)

        self._thread = threading.Thread(target=_loop, name="vidflow-worker", daemon=True)
        self._thread.start()

    def stop_background_loop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    logger.info("Starting standalone VidFlow AI durable worker...")
    worker = VideoJobWorker()
    try:
        while True:
            worker.run_once()
            time.sleep(2.0)
    except KeyboardInterrupt:
        logger.info("Shutting down standalone worker.")

"""Durable object storage manager (Amazon S3 / Cloudflare R2 compatible + persistent local fallback) and media validator."""

import io
import json
import os
import shutil
import subprocess
from typing import Dict, Any, Optional, Tuple
from PIL import Image

from app.config import get_settings


class StorageError(Exception):
    """Raised when media validation or storage operations fail."""


class MediaStorage:
    """Manages durable storage of uploaded reference images, intermediate segments, and final MP4 videos."""

    def __init__(self, base_dir: Optional[str] = None) -> None:
        self.settings = get_settings()
        self.base_dir = os.path.abspath(base_dir or self.settings.local_storage_dir)
        os.makedirs(os.path.join(self.base_dir, "uploads"), exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "segments"), exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "videos"), exist_ok=True)

    def _get_s3_client(self):
        import boto3
        kwargs: Dict[str, Any] = {
            "region_name": self.settings.s3_region,
            "aws_access_key_id": self.settings.s3_access_key_id,
            "aws_secret_access_key": self.settings.s3_secret_access_key,
        }
        if self.settings.s3_endpoint_url:
            kwargs["endpoint_url"] = self.settings.s3_endpoint_url
        return boto3.client("s3", **kwargs)

    def validate_and_inspect_image(self, file_bytes: bytes, content_type: Optional[str] = None) -> Dict[str, Any]:
        """Validate uploaded image size, MIME type, and actual image headers via Pillow."""
        if not file_bytes:
            raise StorageError("קובץ התמונה ריק.")
        if len(file_bytes) > self.settings.max_image_size_bytes:
            max_mb = self.settings.max_image_size_bytes // (1024 * 1024)
            raise StorageError(f"גודל התמונה חורג מהמותר (מקסימום {max_mb}MB).")

        try:
            with Image.open(io.BytesIO(file_bytes)) as img:
                img.verify()
            with Image.open(io.BytesIO(file_bytes)) as img2:
                fmt = (img2.format or "").upper()
                width, height = img2.size
        except Exception as exc:
            raise StorageError("הקובץ שהועלה אינו תמונה תקינה. יש להעלות קובץ JPEG, PNG או WebP תקין.") from exc

        format_to_mime = {
            "JPEG": "image/jpeg",
            "JPG": "image/jpeg",
            "PNG": "image/png",
            "WEBP": "image/webp",
        }
        detected_mime = format_to_mime.get(fmt)
        if not detected_mime or detected_mime not in self.settings.allowed_image_mimes:
            raise StorageError("סוג התמונה אינו נתמך. מותרים קובצי JPEG, PNG ו-WebP בלבד.")

        if width < 64 or height < 64:
            raise StorageError("רזולוציית התמונה נמוכה מדי (מינימום 64x64 פיקסלים).")

        ext_map = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
        return {
            "mime_type": detected_mime,
            "extension": ext_map[detected_mime],
            "width": width,
            "height": height,
            "size_bytes": len(file_bytes),
        }

    @staticmethod
    def inspect_video_file(file_path: str) -> Dict[str, Any]:
        """Validate that a video file exists, is non-empty, has a valid video stream, and measure its duration via ffprobe."""
        if not os.path.exists(file_path):
            raise StorageError("קובץ הווידאו לא נמצא בנתיב השמירה.")
        size = os.path.getsize(file_path)
        if size < 256:
            raise StorageError("קובץ הווידאו שהתקבל קטן מדי או פגום.")

        cmd = [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name,width,height,r_frame_rate:format=duration,size",
            "-of",
            "json",
            file_path,
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20, check=False)
            if proc.returncode != 0:
                raise StorageError(f"בדיקת תקינות הווידאו נכשלה (ffprobe): {proc.stderr.strip()}")
            info = json.loads(proc.stdout or "{}")
            streams = info.get("streams") or []
            if not streams:
                raise StorageError("הקובץ אינו מכיל ערוץ וידאו תקין.")
            fmt = info.get("format") or {}
            duration = float(fmt.get("duration") or 0.0)
            if duration <= 0.05:
                raise StorageError("משך הווידאו שהתקבל הוא 0 שניות או לא תקין.")
            stream = streams[0]
            return {
                "valid": True,
                "duration": round(duration, 2),
                "width": int(stream.get("width") or 0),
                "height": int(stream.get("height") or 0),
                "codec": stream.get("codec_name", "unknown"),
                "size_bytes": size,
            }
        except StorageError:
            raise
        except Exception as exc:
            raise StorageError(f"שגיאה בבדיקת תקינות קובץ הווידאו: {exc}") from exc

    def save_bytes(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        """Save raw bytes to durable storage under `key` (e.g. 'uploads/img_123.jpg' or 'videos/job_123.mp4')."""
        local_path = self.get_local_path(key)
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        with open(local_path, "wb") as f:
            f.write(data)

        if self.settings.is_s3_configured:
            s3 = self._get_s3_client()
            s3.put_object(
                Bucket=self.settings.s3_bucket_name,
                Key=key,
                Body=data,
                ContentType=content_type,
            )
        return key

    def save_file(self, key: str, source_file_path: str, content_type: str = "video/mp4") -> str:
        """Save a local file into durable storage (local durable folder + S3 if configured)."""
        local_dest = self.get_local_path(key)
        os.makedirs(os.path.dirname(local_dest), exist_ok=True)
        if os.path.abspath(source_file_path) != os.path.abspath(local_dest):
            shutil.copy2(source_file_path, local_dest)

        if self.settings.is_s3_configured:
            s3 = self._get_s3_client()
            s3.upload_file(
                local_dest,
                self.settings.s3_bucket_name,
                key,
                ExtraArgs={"ContentType": content_type},
            )
        return key

    def get_local_path(self, key: str) -> str:
        """Resolve storage key to a safe path inside base_dir (preventing path traversal)."""
        clean_key = key.lstrip("/").replace("..", "")
        full_path = os.path.abspath(os.path.join(self.base_dir, clean_key))
        if not full_path.startswith(self.base_dir):
            raise StorageError("נתיב אחסון לא חוקי.")
        return full_path

    def exists(self, key: Optional[str]) -> bool:
        if not key:
            return False
        local_path = self.get_local_path(key)
        if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
            return True
        if self.settings.is_s3_configured:
            try:
                s3 = self._get_s3_client()
                s3.head_object(Bucket=self.settings.s3_bucket_name, Key=key)
                return True
            except Exception:
                return False
        return False

    def get_access_url(self, job_id: str, key: Optional[str], download: bool = False) -> Optional[str]:
        """Generate a presigned S3 URL (if S3 is active) or an authenticated backend media route."""
        if not key:
            return None
        if self.settings.is_s3_configured:
            try:
                s3 = self._get_s3_client()
                params: Dict[str, Any] = {
                    "Bucket": self.settings.s3_bucket_name,
                    "Key": key,
                }
                if download:
                    filename = os.path.basename(key)
                    params["ResponseContentDisposition"] = f'attachment; filename="{filename}"'
                return s3.generate_presigned_url("get_object", Params=params, ExpiresIn=3600)
            except Exception:
                pass
        suffix = "?download=1" if download else ""
        return f"/api/jobs/{job_id}/video{suffix}"

    def delete_key(self, key: Optional[str]) -> None:
        """Delete an object from local storage and S3 (if configured)."""
        if not key:
            return
        try:
            local_path = self.get_local_path(key)
            if os.path.exists(local_path):
                os.remove(local_path)
        except Exception:
            pass
        if self.settings.is_s3_configured:
            try:
                s3 = self._get_s3_client()
                s3.delete_object(Bucket=self.settings.s3_bucket_name, Key=key)
            except Exception:
                pass

"""AI Video Provider integration layer (Replicate API) with strict model schema mapping, status polling, timeouts, and retries."""

import base64
import logging
import mimetypes
import os
import time
from typing import Dict, Any, Optional, Tuple
import httpx

from app.config import get_settings, SUPPORTED_MODELS, VISUAL_STYLES

logger = logging.getLogger("vidflow.provider")


class VideoProviderError(Exception):
    """Raised when the AI video provider fails, times out, or is misconfigured."""


def build_styled_prompt(
    base_prompt: str,
    style_id: str,
    custom_style_prompt: Optional[str] = None,
    aspect_ratio: str = "9:16",
    supports_native_aspect: bool = True,
) -> str:
    """Combine user prompt with selected visual style modifiers and framing guidance."""
    parts = [base_prompt.strip()]
    style_info = VISUAL_STYLES.get(style_id)
    if style_id == "custom" and custom_style_prompt:
        parts.append(f"Visual style: {custom_style_prompt.strip()}")
    elif style_info and style_info.get("modifier"):
        parts.append(f"Style: {style_info['modifier']}")

    if not supports_native_aspect:
        framing_map = {
            "9:16": "vertical 9:16 portrait composition, centered subject suitable for vertical framing",
            "16:9": "widescreen 16:9 horizontal cinematic composition",
            "1:1": "square 1:1 balanced centered composition",
        }
        if aspect_ratio in framing_map:
            parts.append(f"Framing: {framing_map[aspect_ratio]}")

    return ". ".join(p.rstrip(".") for p in parts if p) + "."


class ReplicateVideoProvider:
    """Real AI Video Provider using the official Replicate HTTP REST API."""

    def __init__(self, api_token: Optional[str] = None, base_url: Optional[str] = None) -> None:
        self.settings = get_settings()
        self.api_token = (api_token if api_token is not None else self.settings.replicate_api_token).strip()
        self.base_url = (base_url or self.settings.replicate_api_base).rstrip("/")
        self.timeout_seconds = self.settings.provider_timeout_seconds
        self.poll_interval = self.settings.provider_poll_interval_seconds
        self.max_retries = self.settings.provider_max_retries

    def verify_credentials(self) -> None:
        """Ensure API key is configured before attempting external generation."""
        if not self.api_token:
            raise VideoProviderError(
                "חסר מפתח API של ספק הווידאו (REPLICATE_API_TOKEN אינו מוגדר במשתני הסביבה). "
                "יש להגדיר מפתח תקין כדי להפעיל יצירת וידאו אמיתית."
            )

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @staticmethod
    def encode_image_as_data_uri(image_path: str) -> str:
        """Encode a validated local image file as a base64 data URI for Replicate model input."""
        mime, _ = mimetypes.guess_type(image_path)
        mime = mime or "image/jpeg"
        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        return f"data:{mime};base64,{b64}"

    def build_model_input_payload(
        self,
        model_id: str,
        prompt: str,
        aspect_ratio: str = "9:16",
        segment_duration: int = 5,
        image_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Map generation parameters strictly to the target model's input schema."""
        model_cfg = SUPPORTED_MODELS.get(model_id)
        if not model_cfg:
            raise VideoProviderError(f"המודל '{model_id}' אינו נתמך במערכת.")

        schema = model_cfg["schema"]
        payload: Dict[str, Any] = dict(schema.get("extra_defaults", {}))

        prompt_field = schema.get("prompt_field", "prompt")
        payload[prompt_field] = prompt

        if image_path:
            if not model_cfg.get("supports_image_to_video"):
                raise VideoProviderError(f"המודל '{model_cfg['name']}' אינו תומך ביצירת וידאו מתמונה (Image-to-Video).")
            image_field = schema.get("image_field")
            if not image_field:
                raise VideoProviderError(f"למודל '{model_id}' אין שדה קלט לתמונה.")
            payload[image_field] = self.encode_image_as_data_uri(image_path)

        if model_cfg.get("supports_aspect_ratio_param") and schema.get("aspect_ratio_field"):
            payload[schema["aspect_ratio_field"]] = aspect_ratio

        if schema.get("duration_field"):
            native_durations = model_cfg.get("native_segment_durations", [5])
            chosen_dur = min(native_durations, key=lambda x: abs(x - segment_duration))
            payload[schema["duration_field"]] = f"{chosen_dur}s" if model_id.startswith("luma/") else chosen_dur

        return payload

    def create_prediction(
        self,
        model_id: str,
        prompt: str,
        aspect_ratio: str = "9:16",
        segment_duration: int = 5,
        image_path: Optional[str] = None,
        version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a prediction task on Replicate and return its prediction metadata (including `id` and `status`)."""
        self.verify_credentials()
        input_payload = self.build_model_input_payload(
            model_id=model_id,
            prompt=prompt,
            aspect_ratio=aspect_ratio,
            segment_duration=segment_duration,
            image_path=image_path,
        )

        model_Version = (version or self.settings.video_model_version).strip()
        if model_Version:
            endpoint = f"{self.base_url}/predictions"
            body: Dict[str, Any] = {"version": model_Version, "input": input_payload}
        else:
            # Official Replicate model deployment endpoint: /v1/models/{owner}/{name}/predictions
            endpoint = f"{self.base_url}/models/{model_id}/predictions"
            body = {"input": input_payload}

        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=30.0) as client:
                    resp = client.post(endpoint, headers=self._headers(), json=body)
                if resp.status_code in (200, 201):
                    data = resp.json()
                    pred_id = data.get("id")
                    if not pred_id:
                        raise VideoProviderError("תגובת ספק ה-AI אינה כוללת מזהה משימה (prediction id).")
                    return data
                elif resp.status_code == 401:
                    raise VideoProviderError("אימות מול ספק ה-AI נכשל (401 Unauthorized). בדוק את תקינות המפתח.")
                elif resp.status_code == 402:
                    raise VideoProviderError("חשבון ספק ה-AI החיצוני דורש הסדרת חיוב אצל הספק (402 Payment Required).")
                elif resp.status_code == 429:
                    if attempt < self.max_retries:
                        time.sleep(2.0 * (attempt + 1))
                        continue
                    raise VideoProviderError("חריגה ממגבלת הבקשות של ספק ה-AI החיצוני (429 Rate Limit). נסה שוב בעוד דקה.")
                else:
                    detail = resp.text[:300]
                    raise VideoProviderError(f"שגיאה מיצירת משימה אצל ספק ה-AI (קוד {resp.status_code}): {detail}")
            except VideoProviderError:
                raise
            except httpx.TimeoutException as exc:
                last_err = exc
                if attempt < self.max_retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise VideoProviderError("תם הזמן הקצוב (Timeout) בעת פנייה לספק ה-AI ליצירת המשימה.") from exc
            except Exception as exc:
                last_err = exc
                if attempt < self.max_retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise VideoProviderError(f"שגיאת תקשורת מול ספק ה-AI: {exc}") from exc

        raise VideoProviderError(f"נכשלה יצירת משימה מול ספק ה-AI: {last_err}")

    def get_prediction_status(self, prediction_id: str) -> Dict[str, Any]:
        """Fetch current status of a prediction from Replicate."""
        self.verify_credentials()
        endpoint = f"{self.base_url}/predictions/{prediction_id}"
        try:
            with httpx.Client(timeout=20.0) as client:
                resp = client.get(endpoint, headers=self._headers())
            if resp.status_code != 200:
                raise VideoProviderError(f"שגיאה בבדיקת סטטוס משימה מול הספק (קוד {resp.status_code}).")
            return resp.json()
        except VideoProviderError:
            raise
        except httpx.TimeoutException as exc:
            raise VideoProviderError("תם הזמן הקצוב (Timeout) בבדיקת סטטוס המשימה מול ספק ה-AI.") from exc
        except Exception as exc:
            raise VideoProviderError(f"שגיאה בקבלת סטטוס משימה מספק ה-AI: {exc}") from exc

    @staticmethod
    def extract_output_url(prediction_data: Dict[str, Any]) -> str:
        """Extract the downloadable MP4 URL from Replicate's `output` field."""
        output = prediction_data.get("output")
        if isinstance(output, str) and output.startswith("http"):
            return output
        if isinstance(output, list) and output:
            first = output[0]
            if isinstance(first, str) and first.startswith("http"):
                return first
        if isinstance(output, dict):
            for k in ("video", "url", "mp4"):
                val = output.get(k)
                if isinstance(val, str) and val.startswith("http"):
                    return val
        raise VideoProviderError("המשימה הסתיימה אצל הספק אך לא הוחזר קישור תקין לקובץ הווידאו.")

    def wait_for_prediction(
        self,
        prediction_id: str,
        timeout_seconds: Optional[int] = None,
        poll_interval: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Poll prediction status until it reaches succeeded, failed, or canceled, or times out."""
        max_wait = timeout_seconds if timeout_seconds is not None else self.timeout_seconds
        interval = poll_interval if poll_interval is not None else self.poll_interval
        deadline = time.monotonic() + max_wait

        while time.monotonic() < deadline:
            data = self.get_prediction_status(prediction_id)
            status = data.get("status")
            if status == "succeeded":
                return data
            if status in ("failed", "canceled"):
                err_detail = data.get("error") or "היצירה נכשלה אצל ספק ה-AI."
                raise VideoProviderError(f"יצירת הווידאו נכשלה אצל הספק: {err_detail}")
            time.sleep(interval)

        raise VideoProviderError(f"תם הזמן הקצוב להמתנה לסיום יצירת הווידאו ({max_wait} שניות).")

    def download_video_to_path(self, video_url: str, destination_path: str) -> str:
        """Download the generated video file from provider URL to a local file path with retry support."""
        os.makedirs(os.path.dirname(os.path.abspath(destination_path)), exist_ok=True)
        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=60.0, follow_redirects=True) as client:
                    resp = client.get(video_url)
                if resp.status_code != 200:
                    raise VideoProviderError(f"הורדת קובץ הווידאו מהספק נכשלה (קוד {resp.status_code}).")
                if not resp.content or len(resp.content) < 256:
                    raise VideoProviderError("קובץ הווידאו שהתקבל מהספק ריק או פגום.")
                with open(destination_path, "wb") as f:
                    f.write(resp.content)
                return destination_path
            except VideoProviderError:
                raise
            except httpx.TimeoutException as exc:
                last_err = exc
                if attempt < self.max_retries:
                    time.sleep(1.5)
                    continue
                raise VideoProviderError("תם הזמן הקצוב בעת הורדת קובץ הווידאו מספק ה-AI.") from exc
            except Exception as exc:
                last_err = exc
                if attempt < self.max_retries:
                    time.sleep(1.5)
                    continue
                raise VideoProviderError(f"שגיאה בהורדת הווידאו מהספק: {exc}") from exc

        raise VideoProviderError(f"הורדת הווידאו נכשלה: {last_err}")

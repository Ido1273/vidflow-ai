"""Scene planning and FFmpeg multi-segment stitching for videos up to 60 seconds."""

import math
import os
import subprocess
import tempfile
from typing import List, Dict, Any, Optional
import httpx

from app.config import get_settings, SUPPORTED_MODELS, VISUAL_STYLES
from app.storage import MediaStorage, StorageError
from app.video_provider import build_styled_prompt


class StitcherError(Exception):
    """Raised when multi-segment FFmpeg video normalization or concatenation fails."""


def TargetResolutionForAspect(aspect_ratio: str) -> tuple[int, int]:
    """Return standard HD target resolution (width, height) divisible by 2 for the given aspect ratio."""
    if aspect_ratio == "9:16":
        return (720, 1280)
    if aspect_ratio == "1:1":
        return (720, 720)
    return (1280, 720)  # Default 16:9


class ScenePlanner:
    """Splits a user's video concept into coherent, visually consistent scenes up to 60 seconds."""

    def __init__(self) -> None:
        self.settings = get_settings()

    def plan_segments(
        self,
        prompt: str,
        requested_duration: int,
        model_id: str,
        style: str = "cinematic",
        custom_style_prompt: Optional[str] = None,
        aspect_ratio: str = "9:16",
    ) -> List[Dict[str, Any]]:
        """Calculate required segments and build scene-by-scene prompts with continuity anchors."""
        model_cfg = SUPPORTED_MODELS.get(model_id, SUPPORTED_MODELS["minimax/video-01"])
        native_dur = int(model_cfg.get("default_segment_duration", 5))
        supports_native_aspect = bool(model_cfg.get("supports_aspect_ratio_param", False))

        # Calculate how many segments are needed to reach requested_duration (up to 60s)
        num_segments = max(1, math.ceil(requested_duration / native_dur))
        per_segment_target = round(requested_duration / num_segments, 2)

        styled_base = build_styled_prompt(
            base_prompt=prompt,
            style_id=style,
            custom_style_prompt=custom_style_prompt,
            aspect_ratio=aspect_ratio,
            supports_native_aspect=supports_native_aspect,
        )

        if num_segments == 1:
            return [
                {
                    "segment_index": 0,
                    "total_segments": 1,
                    "scene_prompt": styled_base,
                    "target_duration": float(requested_duration),
                }
            ]

        # Multi-segment planning: maintain strict character, lighting, and style consistency across scenes
        progression_stages = [
            "Opening establishing shot, introducing main subject and atmosphere",
            "Developing action, smooth camera push-in maintaining identical subject and lighting",
            "Dynamic mid-sequence progression, expressive motion and consistent environment",
            "Dramatic build-up, close-up perspective with continuous lighting and textures",
            "Climax sequence, fluid cinematic motion preserving exact character appearance",
            "Resolution shot, graceful camera movement and cohesive visual finish",
        ]

        segments: List[Dict[str, Any]] = []
        for idx in range(num_segments):
            stage_desc = progression_stages[min(idx, len(progression_stages) - 1)]
            continuity_prompt = (
                f"[Scene {idx + 1} of {num_segments} — {stage_desc}] "
                f"{styled_base} "
                f"Maintain strict visual, character, color palette, and lighting continuity with previous scenes."
            )
            segments.append(
                {
                    "segment_index": idx,
                    "total_segments": num_segments,
                    "scene_prompt": continuity_prompt,
                    "target_duration": per_segment_target,
                }
            )
        return segments

    def enhance_prompt(self, prompt: str, style: str = "cinematic", aspect_ratio: str = "9:16") -> Dict[str, Any]:
        """Enhance user prompt using external LLM if OPENAI_API_KEY is configured; otherwise return transparent structured enhancement."""
        cleaned = prompt.strip()
        if not self.settings.is_prompt_enhancer_configured:
            raise ValueError(
                "שירות שיפור הפרומפט באמצעות מודל שפה חיצוני אינו מוגדר כעת (OPENAI_API_KEY חסר). "
                "ניתן להשתמש בפרומפט שלך ישירות — המערכת תשלב אוטומטית את הגדרות הסגנון והמצלמה."
            )

        endpoint = f"{self.settings.openai_api_base}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.settings.openai_api_key}",
            "Content-Type": "application/json",
        }
        system_msg = (
            "You are an expert AI video director. Enhance the user's video generation prompt with cinematic lighting, "
            "camera movement, subject detail, and realistic motion while preserving the core idea. Reply with the enhanced prompt only."
        )
        payload = {
            "model": self.settings.scene_planner_model,
            "messages": [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": f"Prompt: {cleaned}\nStyle: {style}\nAspect Ratio: {aspect_ratio}"},
            ],
            "temperature": 0.7,
            "max_tokens": 350,
        }
        with httpx.Client(timeout=20.0) as client:
            resp = client.post(endpoint, headers=headers, json=payload)
        if resp.status_code != 200:
            raise RuntimeError(f"שגיאה משירות שיפור הפרומפט (קוד {resp.status_code}).")
        data = resp.json()
        enhanced = data["choices"][0]["message"]["content"].strip()
        return {
            "original_prompt": cleaned,
            "enhanced_prompt": enhanced,
            "used_external_llm": True,
            "notice_he": "הפרומפט שופר באמצעות מודל שפה (AI).",
        }


class VideoStitcher:
    """Normalizes and stitches video segments into a seamless final MP4 using FFmpeg."""

    @staticmethod
    def normalize_and_trim_segment(
        input_path: str,
        output_path: str,
        aspect_ratio: str = "9:16",
        target_duration: Optional[float] = None,
        fps: int = 24,
    ) -> Dict[str, Any]:
        """Normalize a single segment to exact target aspect ratio, resolution, pixel format (yuv420p), and frame rate without black bars or corruption."""
        if not os.path.exists(input_path):
            raise StitcherError(f"קובץ המקטע לא נמצא: {input_path}")

        target_w, target_h = TargetResolutionForAspect(aspect_ratio)
        # Scale and center-crop cleanly to fill the target aspect ratio without distortion or black bars
        vf_filter = (
            f"scale={target_w}:{target_h}:force_original_aspect_ratio=increase,"
            f"crop={target_w}:{target_h},"
            f"fps={fps},format=yuv420p,setsar=1"
        )

        cmd = ["ffmpeg", "-y", "-i", input_path]
        if target_duration and target_duration > 0:
            cmd += ["-t", f"{target_duration:.2f}"]
        cmd += [
            "-vf",
            vf_filter,
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-crf",
            "23",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            "-an",
            output_path,
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120, check=False)
        if proc.returncode != 0:
            raise StitcherError(f"נכשל עיבוד מקטע וידאו ב-FFmpeg: {proc.stderr[-300:]}")

        try:
            return MediaStorage.inspect_video_file(output_path)
        except StorageError as exc:
            raise StitcherError(str(exc)) from exc

    @classmethod
    def stitch_segments(
        cls,
        segment_paths: List[str],
        output_path: str,
        aspect_ratio: str = "9:16",
        target_total_duration: Optional[float] = None,
        fps: int = 24,
    ) -> Dict[str, Any]:
        """Normalize all segments to identical codec/resolution/FPS and concatenate them seamlessly into a single MP4."""
        if not segment_paths:
            raise StitcherError("לא סופקו מקטעי וידאו לחיבור.")

        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        per_seg_dur = (
            round(target_total_duration / len(segment_paths), 2)
            if target_total_duration and target_total_duration > 0
            else None
        )

        with tempfile.TemporaryDirectory() as tmp_dir:
            normalized_paths: List[str] = []
            for idx, seg_path in enumerate(segment_paths):
                norm_path = os.path.join(tmp_dir, f"norm_{idx:03d}.mp4")
                cls.normalize_and_trim_segment(
                    input_path=seg_path,
                    output_path=norm_path,
                    aspect_ratio=aspect_ratio,
                    target_duration=per_seg_dur,
                    fps=fps,
                )
                normalized_paths.append(norm_path)

            if len(normalized_paths) == 1:
                import shutil
                shutil.copy2(normalized_paths[0], output_path)
            else:
                concat_list_path = os.path.join(tmp_dir, "concat_list.txt")
                with open(concat_list_path, "w", encoding="utf-8") as f:
                    for p in normalized_paths:
                        escaped = p.replace("'", "'\\''")
                        f.write(f"file '{escaped}'\n")

                # Re-encode concatenation to guarantee monotonic PTS timestamps and zero black-frame glitches
                cmd = [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    concat_list_path,
                    "-c:v",
                    "libx264",
                    "-preset",
                    "ultrafast",
                    "-crf",
                    "23",
                    "-pix_fmt",
                    "yuv420p",
                    "-movflags",
                    "+faststart",
                    output_path,
                ]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180, check=False)
                if proc.returncode != 0:
                    raise StitcherError(f"חיבור מקטעי הווידאו ב-FFmpeg נכשל: {proc.stderr[-300:]}")

        try:
            return MediaStorage.inspect_video_file(output_path)
        except StorageError as exc:
            raise StitcherError(str(exc)) from exc

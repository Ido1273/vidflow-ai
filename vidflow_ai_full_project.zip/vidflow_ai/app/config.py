"""Configuration and environment settings for VidFlow AI."""

import os
from typing import Dict, Any, List
from dotenv import load_dotenv

load_dotenv()


class Settings:
    """Centralized configuration loaded from environment variables."""

    def __init__(self) -> None:
        self.app_name: str = os.getenv("APP_NAME", "VidFlow AI")
        self.app_env: str = os.getenv("APP_ENV", "development")
        self.secret_key: str = os.getenv("SECRET_KEY", "vidflow-default-session-secret-change-in-prod")

        # Database Configuration (SQLite for local dev, PostgreSQL ready for Render)
        self.database_url: str = os.getenv("DATABASE_URL", "sqlite:///./vidflow.db")

        # AI Video Provider Configuration (Replicate API)
        self.video_provider: str = os.getenv("VIDEO_PROVIDER", "replicate").lower()
        self.replicate_api_token: str = os.getenv("REPLICATE_API_TOKEN", "").strip()
        self.replicate_api_base: str = os.getenv("REPLICATE_API_BASE", "https://api.replicate.com/v1").rstrip("/")
        self.default_video_model: str = os.getenv("VIDEO_MODEL", "minimax/video-01").strip()
        self.video_model_version: str = os.getenv("VIDEO_MODEL_VERSION", "").strip()

        # Optional LLM Scene Planner & Prompt Enhancer (OpenAI-compatible or Replicate LLM)
        self.openai_api_key: str = os.getenv("OPENAI_API_KEY", "").strip()
        self.openai_api_base: str = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
        self.scene_planner_model: str = os.getenv("SCENE_PLANNER_MODEL", "gpt-4o-mini").strip()

        # Provider Polling & Timeout Settings
        self.provider_timeout_seconds: int = int(os.getenv("PROVIDER_TIMEOUT_SECONDS", "420"))
        self.provider_poll_interval_seconds: float = float(os.getenv("PROVIDER_POLL_INTERVAL_SECONDS", "3.0"))
        self.provider_max_retries: int = int(os.getenv("PROVIDER_MAX_RETRIES", "2"))

        # Object Storage Configuration (S3 / Cloudflare R2 / Local durable fallback)
        self.storage_backend: str = os.getenv("STORAGE_BACKEND", "local").lower()  # "s3" or "local"
        self.local_storage_dir: str = os.getenv("LOCAL_STORAGE_DIR", "./storage_data")
        self.s3_endpoint_url: str = os.getenv("S3_ENDPOINT_URL", "").strip()
        self.s3_region: str = os.getenv("S3_REGION", "us-east-1").strip()
        self.s3_bucket_name: str = os.getenv("S3_BUCKET_NAME", "").strip()
        self.s3_access_key_id: str = os.getenv("S3_ACCESS_KEY_ID", "").strip()
        self.s3_secret_access_key: str = os.getenv("S3_SECRET_ACCESS_KEY", "").strip()
        self.s3_public_base_url: str = os.getenv("S3_PUBLIC_BASE_URL", "").strip()

        # File Upload Constraints
        self.max_image_size_bytes: int = int(os.getenv("MAX_IMAGE_SIZE_BYTES", str(10 * 1024 * 1024)))  # 10 MB
        self.allowed_image_mimes: List[str] = ["image/jpeg", "image/png", "image/webp"]

        # Technical Rate Limiting (Abuse prevention only — NO credits or billing!)
        self.rate_limit_requests_per_minute: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "15"))

        # Worker configuration
        self.enable_embedded_worker: bool = os.getenv("ENABLE_EMBEDDED_WORKER", "true").lower() in ("1", "true", "yes")

    @property
    def is_provider_configured(self) -> bool:
        """Return True if the selected external AI video provider has valid credentials configured."""
        if self.video_provider == "replicate":
            return bool(self.replicate_api_token)
        return False

    @property
    def is_prompt_enhancer_configured(self) -> bool:
        """Return True if an LLM API key is configured for AI prompt enhancement."""
        return bool(self.openai_api_key)

    @property
    def is_s3_configured(self) -> bool:
        """Return True if S3-compatible object storage is configured."""
        return (
            self.storage_backend == "s3"
            and bool(self.s3_bucket_name)
            and bool(self.s3_access_key_id)
            and bool(self.s3_secret_access_key)
        )


# Supported Video Models and their exact input schema & capabilities
SUPPORTED_MODELS: Dict[str, Dict[str, Any]] = {
    "minimax/video-01": {
        "id": "minimax/video-01",
        "name": "MiniMax Video-01 (Hailuo)",
        "provider": "replicate",
        "supports_text_to_video": True,
        "supports_image_to_video": True,
        "native_segment_durations": [6],
        "default_segment_duration": 6,
        "max_total_duration": 60,
        "supported_aspect_ratios": ["16:9", "9:16", "1:1"],
        "supports_aspect_ratio_param": False,  # Normalized via FFmpeg + prompt guidance
        "schema": {
            "prompt_field": "prompt",
            "image_field": "first_frame_image",
            "extra_defaults": {"prompt_optimizer": True},
        },
        "description_he": "מודל קולנועי מתקדם התומך ביצירה מטקסט ומתמונה (אורך מקטע טבעי: 6 שניות, עד 60 שניות בחיבור סצנות חכם).",
    },
    "luma/ray-2-720p": {
        "id": "luma/ray-2-720p",
        "name": "Luma Dream Machine Ray-2 (720p)",
        "provider": "replicate",
        "supports_text_to_video": True,
        "supports_image_to_video": True,
        "native_segment_durations": [5, 9],
        "default_segment_duration": 5,
        "max_total_duration": 60,
        "supported_aspect_ratios": ["16:9", "9:16", "1:1"],
        "supports_aspect_ratio_param": True,
        "schema": {
            "prompt_field": "prompt",
            "image_field": "start_image_url",
            "aspect_ratio_field": "aspect_ratio",
            "duration_field": "duration",
            "extra_defaults": {},
        },
        "description_he": "מודל Luma Ray-2 מהיר וחד עם תמיכה מובנית ביחסי תצוגה (9:16, 16:9, 1:1), תמונת פתיחה ומקטעים של 5 שניות.",
    },
    "wan-video/wan-2.1-t2v-480p": {
        "id": "wan-video/wan-2.1-t2v-480p",
        "name": "Wan 2.1 Text-to-Video",
        "provider": "replicate",
        "supports_text_to_video": True,
        "supports_image_to_video": False,  # Strictly Text-to-Video only
        "native_segment_durations": [5],
        "default_segment_duration": 5,
        "max_total_duration": 60,
        "supported_aspect_ratios": ["16:9", "9:16", "1:1"],
        "supports_aspect_ratio_param": True,
        "schema": {
            "prompt_field": "prompt",
            "image_field": None,
            "aspect_ratio_field": "aspect_ratio",
            "extra_defaults": {"frames": 81, "fps": 16},
        },
        "description_he": "מודל Text-to-Video ייעודי (ללא העלאת תמונה) לתנועה חלקה ויצירת סצנות מרובות עד 60 שניות.",
    },
}

# Supported Visual Styles and their prompt engineering modifiers
VISUAL_STYLES: Dict[str, Dict[str, str]] = {
    "realistic": {
        "id": "realistic",
        "label_he": "ריאליסטי",
        "modifier": "photorealistic, ultra-detailed, natural lighting, authentic textures, 8k raw footage look, lifelike motion",
    },
    "cinematic": {
        "id": "cinematic",
        "label_he": "קולנועי",
        "modifier": "cinematic film look, anamorphic lens, dramatic lighting, shallow depth of field, color graded, movie scene",
    },
    "animation": {
        "id": "animation",
        "label_he": "אנימציה",
        "modifier": "high-end 3D Pixar-style animation, expressive character movement, vibrant colors, stylized lighting, smooth rendering",
    },
    "fantasy": {
        "id": "fantasy",
        "label_he": "פנטזיה",
        "modifier": "epic fantasy world, magical atmosphere, ethereal glowing particles, mystical lighting, breathtaking scenery",
    },
    "commercial": {
        "id": "commercial",
        "label_he": "פרסומת",
        "modifier": "high-end commercial product advertisement, studio lighting, crisp focus, dynamic camera sweep, sleek modern aesthetic",
    },
    "emotional": {
        "id": "emotional",
        "label_he": "סיפור רגשי",
        "modifier": "emotional storytelling, intimate framing, warm soft lighting, expressive subtle facial emotion, poignant atmosphere",
    },
    "viral": {
        "id": "viral",
        "label_he": "תוכן ויראלי לרשתות",
        "modifier": "high-energy engaging social video, punchy visual hook, vibrant contrast, dynamic pacing, sharp subject focus",
    },
    "custom": {
        "id": "custom",
        "label_he": "סגנון מותאם אישית",
        "modifier": "",
    },
}

ALLOWED_DURATIONS: List[int] = [5, 10, 15, 30, 45, 60]
ALLOWED_ASPECT_RATIOS: List[str] = ["9:16", "16:9", "1:1"]


def get_settings() -> Settings:
    return Settings()

"""FastAPI Backend for VidFlow AI — Up to 60s AI Video Generation Platform."""

import hmac
import hashlib
import logging
import os
import shutil
import time
import uuid
from collections import defaultdict
from typing import Dict, Any, List, Optional

from fastapi import (
    FastAPI,
    Request,
    Response,
    UploadFile,
    File,
    Form,
    HTTPException,
    Depends,
    BackgroundTasks,
    Query,
)
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.config import (
    get_settings,
    SUPPORTED_MODELS,
    VISUAL_STYLES,
    ALLOWED_DURATIONS,
    ALLOWED_ASPECT_RATIOS,
)
from app.database import Database
from app.models import (
    GenerateJobRequest,
    JobResponse,
    EnhancePromptRequest,
    EnhancePromptResponse,
)
from app.storage import MediaStorage, StorageError
from app.video_provider import ReplicateVideoProvider, build_styled_prompt
from app.stitcher import ScenePlanner
from app.worker import VideoJobWorker

logger = logging.getLogger("vidflow.api")

# Technical in-memory sliding window rate limiter (Strictly technical protection — NO credits or subscriptions!)
_rate_limit_buckets: Dict[str, List[float]] = defaultdict(list)


def create_app(
    db: Optional[Database] = None,
    storage: Optional[MediaStorage] = None,
    provider: Optional[ReplicateVideoProvider] = None,
    start_worker: Optional[bool] = None,
) -> FastAPI:
    settings = get_settings()
    app_db = db or Database()
    app_storage = storage or MediaStorage()
    app_provider = provider or ReplicateVideoProvider()
    app_worker = VideoJobWorker(db=app_db, storage=app_storage, provider=app_provider)
    app_planner = ScenePlanner()

    app = FastAPI(
        title="VidFlow AI — פלטפורמת יצירת וידאו בבינה מלאכותית",
        description="יצירת סרטוני AI מקצועיים מטקסט או מתמונה באורך של עד 60 שניות, ללא מערכת קרדיטים וללא חיבור לרשתות חברתיות.",
        version="2.0.0",
    )

    # Store dependencies on app.state for easy access and test injection
    app.state.db = app_db
    app.state.storage = app_storage
    app.state.provider = app_provider
    app.state.worker = app_worker
    app.state.planner = app_planner

    should_start_worker = start_worker if start_worker is not None else settings.enable_embedded_worker

    @app.on_event("startup")
    def _on_startup() -> None:
        if should_start_worker:
            app_worker.start_background_loop()

    @app.on_event("shutdown")
    def _on_shutdown() -> None:
        app_worker.stop_background_loop()

    def _sign_user_id(user_id: str) -> str:
        sig = hmac.new(settings.secret_key.encode("utf-8"), user_id.encode("utf-8"), hashlib.sha256).hexdigest()[:16]
        return f"{user_id}.{sig}"

    def _verify_signed_token(token: str) -> Optional[str]:
        if not token or "." not in token:
            return None
        uid, sig = token.rsplit(".", 1)
        expected = hmac.new(settings.secret_key.encode("utf-8"), uid.encode("utf-8"), hashlib.sha256).hexdigest()[:16]
        if hmac.compare_digest(sig, expected):
            return uid
        return None

    def get_current_user_id(request: Request, response: Response) -> str:
        """Resolve or assign an isolated user session token so users cannot access private jobs of others by job_id alone."""
        header_token = request.headers.get("X-VidFlow-Session", "").strip()
        cookie_token = request.cookies.get("vidflow_session", "").strip()

        for candidate in (header_token, cookie_token):
            verified = _verify_signed_token(candidate)
            if verified:
                return verified

        # Also allow raw user ID header in automated tests if prefixed with test_user_
        if header_token.startswith("test_user_"):
            return header_token

        new_uid = f"usr_{uuid.uuid4().hex[:12]}"
        signed = _sign_user_id(new_uid)
        response.set_cookie(
            key="vidflow_session",
            value=signed,
            httponly=True,
            samesite="lax",
            max_age=60 * 60 * 24 * 90,
        )
        response.headers["X-VidFlow-Session"] = signed
        return new_uid

    def check_rate_limit(user_id: str) -> None:
        """Technical rate limiting to prevent server overload (not a credit system)."""
        limit = get_settings().rate_limit_requests_per_minute
        now = time.monotonic()
        window = _rate_limit_buckets[user_id]
        _rate_limit_buckets[user_id] = [t for t in window if now - t < 60.0]
        if len(_rate_limit_buckets[user_id]) >= limit:
            raise HTTPException(
                status_code=429,
                detail="בוצעו יותר מדי בקשות בדקה האחרונה (הגבלת עומס טכנית). אנא המתן מספר שניות ונסה שוב.",
            )
        _rate_limit_buckets[user_id].append(now)

    def _serialize_job(job: Dict[str, Any]) -> Dict[str, Any]:
        jid = job["id"]
        out_key = job.get("output_video_key")
        in_key = job.get("input_image_key")
        video_url = app.state.storage.get_access_url(jid, out_key, download=False) if out_key else None
        download_url = app.state.storage.get_access_url(jid, out_key, download=True) if out_key else None
        input_image_url = f"/api/jobs/{jid}/input-image" if in_key else None

        return {
            **job,
            "video_url": video_url,
            "download_url": download_url,
            "input_image_url": input_image_url,
            "thumbnail_url": input_image_url,
        }

    @app.get("/health")
    def health_check() -> Dict[str, Any]:
        """System health check verifying DB, FFmpeg availability, Storage, and AI provider configuration status."""
        cur_settings = get_settings()
        db_ok = app.state.db.check_health()
        ffmpeg_ok = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None
        provider_configured = bool(app.state.provider.api_token or cur_settings.is_provider_configured)

        return {
            "status": "ok" if (db_ok and ffmpeg_ok) else "degraded",
            "app": cur_settings.app_name,
            "version": "2.0.0",
            "database": "connected" if db_ok else "error",
            "database_backend": "postgresql" if app.state.db.is_postgres else "sqlite",
            "ffmpeg_available": ffmpeg_ok,
            "storage_backend": "s3" if cur_settings.is_s3_configured else "local_durable",
            "ai_provider": cur_settings.video_provider,
            "ai_provider_configured": provider_configured,
            "prompt_enhancer_configured": cur_settings.is_prompt_enhancer_configured,
            "credits_system_enabled": False,
            "social_publishing_enabled": False,
        }

    @app.get("/api/config")
    def get_client_config(request: Request, response: Response, user_id: str = Depends(get_current_user_id)) -> Dict[str, Any]:
        """Return supported models, capabilities, aspect ratios, durations, styles, and provider status to the Frontend."""
        cur_settings = get_settings()
        provider_ready = bool(app.state.provider.api_token or cur_settings.is_provider_configured)
        return {
            "app_name": "VidFlow AI",
            "session_token": _sign_user_id(user_id),
            "provider": {
                "name": cur_settings.video_provider,
                "configured": provider_ready,
                "default_model": cur_settings.default_video_model,
                "prompt_enhancer_configured": cur_settings.is_prompt_enhancer_configured,
                "external_billing_notice_he": (
                    "יצירת הסרטונים ב-VidFlow AI פועלת ללא מערכת קרדיטים או מנויים פנימית. "
                    "שים לב שספק ה-AI החיצוני (כגון Replicate) מחייב את חשבון המפתח לפי שימוש בפועל ומפעיל מגבלות חשבון משלו."
                ),
            },
            "models": list(SUPPORTED_MODELS.values()),
            "styles": list(VISUAL_STYLES.values()),
            "allowed_durations": ALLOWED_DURATIONS,
            "allowed_aspect_ratios": ALLOWED_ASPECT_RATIOS,
            "max_image_size_mb": cur_settings.max_image_size_bytes // (1024 * 1024),
            "allowed_image_mimes": cur_settings.allowed_image_mimes,
        }

    @app.post("/api/enhance-prompt", response_model=EnhancePromptResponse)
    def enhance_prompt_endpoint(payload: EnhancePromptRequest) -> Dict[str, Any]:
        """Enhance user prompt via external LLM if configured; otherwise return clear explanation (never fake it)."""
        try:
            return app.state.planner.enhance_prompt(
                prompt=payload.prompt,
                style=payload.style,
                aspect_ratio=payload.aspect_ratio,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"שגיאה בשיפור הפרומפט: {exc}") from exc

    @app.post("/api/generate", status_code=201)
    async def create_generation_job(
        request: Request,
        response: Response,
        background_tasks: BackgroundTasks,
        prompt: str = Form(""),
        mode: str = Form("text_to_video"),
        model_id: str = Form("minimax/video-01"),
        requested_duration: int = Form(5),
        aspect_ratio: str = Form("9:16"),
        style: str = Form("cinematic"),
        custom_style_prompt: Optional[str] = Form(None),
        image: Optional[UploadFile] = File(None),
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """Create a new AI video generation task (supports both multipart Form+File and JSON requests)."""
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                body = await request.json()
            except Exception as exc:
                raise HTTPException(status_code=400, detail="גוף הבקשה אינו JSON תקין.") from exc
            prompt = str(body.get("prompt") or "")
            mode = str(body.get("mode") or "text_to_video")
            model_id = str(body.get("model_id") or "minimax/video-01")
            requested_duration = int(body.get("requested_duration") or 5)
            aspect_ratio = str(body.get("aspect_ratio") or "9:16")
            style = str(body.get("style") or "cinematic")
            custom_style_prompt = body.get("custom_style_prompt")

        check_rate_limit(user_id)

        # Validate input fields via Pydantic
        try:
            validated = GenerateJobRequest(
                prompt=prompt,
                mode=mode,
                model_id=model_id,
                requested_duration=requested_duration,
                aspect_ratio=aspect_ratio,
                style=style,
                custom_style_prompt=custom_style_prompt,
            )
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"נתוני הקלט אינם תקינים: {exc}") from exc

        model_cfg = SUPPORTED_MODELS.get(validated.model_id)
        if not model_cfg:
            raise HTTPException(status_code=400, detail=f"המודל המבוקש אינו נתמך: {validated.model_id}")

        if validated.aspect_ratio not in model_cfg["supported_aspect_ratios"]:
            raise HTTPException(
                status_code=400,
                detail=f"יחס התצוגה {validated.aspect_ratio} אינו נתמך על ידי המודל {model_cfg['name']}.",
            )

        # Verify AI provider API key is present before queuing job
        try:
            app.state.provider.verify_credentials()
        except Exception as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        job_id = f"job_{uuid.uuid4().hex[:16]}"
        input_image_key: Optional[str] = None

        if validated.mode == "image_to_video":
            if not model_cfg.get("supports_image_to_video"):
                raise HTTPException(
                    status_code=400,
                    detail=f"המודל '{model_cfg['name']}' אינו תומך ביצירת סרטון מתמונה (Image to Video).",
                )
            if not image or not image.filename:
                raise HTTPException(
                    status_code=400,
                    detail="נבחר מצב יצירה מתמונה (Image to Video), אך לא הועלה קובץ תמונה.",
                )
            raw_bytes = await image.read()
            try:
                img_meta = app.state.storage.validate_and_inspect_image(raw_bytes, image.content_type)
            except StorageError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            input_image_key = f"uploads/{job_id}{img_meta['extension']}"
            app.state.storage.save_bytes(input_image_key, raw_bytes, content_type=img_meta["mime_type"])
        elif image and image.filename:
            # If user uploaded an image without explicitly switching mode, validate model support
            if not model_cfg.get("supports_image_to_video"):
                raise HTTPException(
                    status_code=400,
                    detail=f"המודל '{model_cfg['name']}' אינו תומך בהעלאת תמונה.",
                )
            raw_bytes = await image.read()
            try:
                img_meta = app.state.storage.validate_and_inspect_image(raw_bytes, image.content_type)
            except StorageError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            input_image_key = f"uploads/{job_id}{img_meta['extension']}"
            app.state.storage.save_bytes(input_image_key, raw_bytes, content_type=img_meta["mime_type"])
            validated.mode = "image_to_video"

        # Plan segments for requested duration (up to 60s)
        planned_segments = app.state.planner.plan_segments(
            prompt=validated.prompt,
            requested_duration=validated.requested_duration,
            model_id=validated.model_id,
            style=validated.style,
            custom_style_prompt=validated.custom_style_prompt,
            aspect_ratio=validated.aspect_ratio,
        )

        enhanced_preview = build_styled_prompt(
            base_prompt=validated.prompt,
            style_id=validated.style,
            custom_style_prompt=validated.custom_style_prompt,
            aspect_ratio=validated.aspect_ratio,
            supports_native_aspect=bool(model_cfg.get("supports_aspect_ratio_param", False)),
        )

        job = app.state.db.create_job(
            job_id=job_id,
            user_id=user_id,
            prompt=validated.prompt,
            enhanced_prompt=enhanced_preview,
            mode=validated.mode,
            model_id=validated.model_id,
            style=validated.style,
            custom_style_prompt=validated.custom_style_prompt,
            aspect_ratio=validated.aspect_ratio,
            requested_duration=validated.requested_duration,
            provider_name=model_cfg["provider"],
            input_image_key=input_image_key,
            segment_count=len(planned_segments),
        )

        for seg in planned_segments:
            app.state.db.create_segment(
                job_id=job_id,
                segment_index=seg["segment_index"],
                total_segments=seg["total_segments"],
                scene_prompt=seg["scene_prompt"],
                target_duration=seg["target_duration"],
            )

        # Schedule background processing immediately
        background_tasks.add_task(app.state.worker.process_job_sync, job_id)

        fresh_job = app.state.db.get_job(job_id, user_id=user_id)
        return _serialize_job(fresh_job)

    @app.get("/api/jobs")
    def list_user_jobs(
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """List all video generation jobs belonging to the current user session."""
        jobs = app.state.db.list_jobs(user_id=user_id)
        return {"jobs": [_serialize_job(j) for j in jobs]}

    @app.get("/api/jobs/{job_id}")
    def get_job_details(
        job_id: str,
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """Get full status and segment progress for a specific job (isolated per user)."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job:
            raise HTTPException(status_code=404, detail="המשימה לא נמצאה או שאין לך הרשאת גישה אליה.")
        return _serialize_job(job)

    @app.post("/api/jobs/{job_id}/retry")
    def retry_failed_job(
        job_id: str,
        background_tasks: BackgroundTasks,
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """Retry a failed or canceled job (preserving already succeeded segments so only failed segments re-run)."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job:
            raise HTTPException(status_code=404, detail="המשימה לא נמצאה או שאין לך הרשאת גישה אליה.")
        if job["status"] not in ("failed", "canceled"):
            raise HTTPException(status_code=400, detail="ניתן לנסות שוב רק משימות שנכשלו או בוטלו.")

        # Reset failed segments so worker re-runs them while preserving succeeded segments
        for seg in job.get("segments", []):
            if seg["status"] != "succeeded":
                app.state.db.update_segment(
                    seg["id"],
                    status="pending",
                    provider_prediction_id=None,
                    error_message=None,
                )

        app.state.db.update_job(
            job_id,
            status="queued",
            status_message_he="מנסה שוב להשלים את הסצנות שנכשלו...",
            error_message=None,
        )
        background_tasks.add_task(app.state.worker.process_job_sync, job_id)
        updated = app.state.db.get_job(job_id, user_id=user_id)
        return _serialize_job(updated)

    @app.post("/api/jobs/{job_id}/cancel")
    def cancel_job(
        job_id: str,
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """Cancel an in-progress or queued job."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job:
            raise HTTPException(status_code=404, detail="המשימה לא נמצאה.")
        if job["status"] in ("succeeded", "failed", "canceled"):
            return _serialize_job(job)
        app.state.db.update_job(
            job_id,
            status="canceled",
            status_message_he="המשימה בוטלה על ידי המשתמש.",
        )
        return _serialize_job(app.state.db.get_job(job_id, user_id=user_id))

    @app.get("/api/jobs/{job_id}/video")
    def stream_or_download_video(
        job_id: str,
        request: Request,
        response: Response,
        download: int = Query(0),
        user_id: str = Depends(get_current_user_id),
    ):
        """Stream or download the final verified MP4 video (enforcing user ownership and file integrity)."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job:
            raise HTTPException(status_code=404, detail="המשימה לא נמצאה או שאין לך הרשאת גישה אליה.")
        if job["status"] != "succeeded" or not job.get("output_video_key"):
            raise HTTPException(status_code=409, detail="הסרטון עדיין אינו מוכן לצפייה או להורדה.")

        out_key = job["output_video_key"]
        if get_settings().is_s3_configured:
            presigned = app.state.storage.get_access_url(job_id, out_key, download=bool(download))
            if presigned and presigned.startswith("http"):
                return RedirectResponse(url=presigned)

        local_path = app.state.storage.get_local_path(out_key)
        if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
            raise HTTPException(status_code=404, detail="קובץ הווידאו חסר או נמחק מהאחסון.")

        filename = f"vidflow_{job_id}.mp4"
        headers = {}
        if download:
            headers["Content-Disposition"] = f'attachment; filename="{filename}"'
        else:
            headers["Content-Disposition"] = f'inline; filename="{filename}"'
        return FileResponse(local_path, media_type="video/mp4", headers=headers)

    @app.get("/api/jobs/{job_id}/input-image")
    def get_job_input_image(
        job_id: str,
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ):
        """Return the uploaded source image for an Image-to-Video job (isolated per user)."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job or not job.get("input_image_key"):
            raise HTTPException(status_code=404, detail="תמונת המקור לא נמצאה.")
        local_path = app.state.storage.get_local_path(job["input_image_key"])
        if not os.path.exists(local_path):
            raise HTTPException(status_code=404, detail="קובץ התמונה לא נמצא באחסון.")
        return FileResponse(local_path)

    @app.delete("/api/jobs/{job_id}")
    def delete_user_job(
        job_id: str,
        request: Request,
        response: Response,
        user_id: str = Depends(get_current_user_id),
    ) -> Dict[str, Any]:
        """Delete a job and clean up its associated video, segment files, and uploaded image from storage."""
        job = app.state.db.get_job(job_id, user_id=user_id)
        if not job:
            raise HTTPException(status_code=404, detail="המשימה לא נמצאה או שאין לך הרשאת מחיקה עבורה.")

        # Delete stored files
        app.state.storage.delete_key(job.get("output_video_key"))
        app.state.storage.delete_key(job.get("input_image_key"))
        for seg in job.get("segments", []):
            app.state.storage.delete_key(seg.get("storage_key"))

        deleted = app.state.db.delete_job(job_id, user_id=user_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="מחיקת המשימה נכשלה.")
        return {"deleted": True, "job_id": job_id}

    # Serve Frontend static assets if present
    static_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")
    if os.path.isdir(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

        @app.get("/", response_class=HTMLResponse)
        def serve_spa_index() -> HTMLResponse:
            index_path = os.path.join(static_dir, "index.html")
            if os.path.exists(index_path):
                with open(index_path, "r", encoding="utf-8") as f:
                    return HTMLResponse(content=f.read())
            return HTMLResponse(content="<h1>VidFlow AI Backend Running</h1>")

    return app


app = create_app()

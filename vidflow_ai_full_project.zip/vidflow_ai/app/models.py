"""Pydantic schemas and status enums for VidFlow AI."""

from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, validator


class JobStatus(str, Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    STITCHING = "stitching"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELED = "canceled"


class SegmentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class GenerateJobRequest(BaseModel):
    prompt: str = Field(..., min_length=3, max_length=2000, description="תיאור הסרטון או התנועה המבוקשת")
    mode: str = Field("text_to_video", description="text_to_video or image_to_video")
    model_id: str = Field("minimax/video-01", description="מזהה מודל הווידאו")
    requested_duration: int = Field(5, description="אורך הסרטון המבוקש בשניות (5, 10, 15, 30, 45, 60)")
    aspect_ratio: str = Field("9:16", description="יחס תצוגה: 9:16, 16:9, 1:1")
    style: str = Field("cinematic", description="סגנון ויזואלי")
    custom_style_prompt: Optional[str] = Field(None, max_length=500, description="תיאור סגנון מותאם אישית")

    @validator("prompt")
    def validate_prompt_clean(cls, v: str) -> str:
        cleaned = v.strip()
        if len(cleaned) < 3:
            raise ValueError("הפרומפט חייב להכיל לפחות 3 תווים.")
        return cleaned

    @validator("mode")
    def validate_mode(cls, v: str) -> str:
        if v not in ("text_to_video", "image_to_video"):
            raise ValueError("מצב יצירה לא חוקי. יש לבחור text_to_video או image_to_video.")
        return v

    @validator("requested_duration")
    def validate_duration(cls, v: int) -> int:
        if v not in (5, 10, 15, 30, 45, 60):
            raise ValueError("אורך הסרטון חייב להיות אחד מהערכים: 5, 10, 15, 30, 45 או 60 שניות.")
        return v

    @validator("aspect_ratio")
    def validate_aspect_ratio(cls, v: str) -> str:
        if v not in ("9:16", "16:9", "1:1"):
            raise ValueError("יחס תצוגה לא נתמך. אפשרויות חוקיות: 9:16, 16:9, 1:1.")
        return v


class SegmentResponse(BaseModel):
    id: str
    job_id: str
    segment_index: int
    total_segments: int
    scene_prompt: str
    target_duration: float
    actual_duration: Optional[float] = None
    status: str
    provider_prediction_id: Optional[str] = None
    storage_key: Optional[str] = None
    error_message: Optional[str] = None
    retry_count: int = 0
    created_at: str
    updated_at: str


class JobResponse(BaseModel):
    id: str
    user_id: str
    prompt: str
    enhanced_prompt: Optional[str] = None
    mode: str
    model_id: str
    style: str
    custom_style_prompt: Optional[str] = None
    aspect_ratio: str
    requested_duration: int
    actual_duration: Optional[float] = None
    status: str
    progress_percent: int
    status_message_he: str
    provider_name: str
    provider_job_id: Optional[str] = None
    input_image_key: Optional[str] = None
    input_image_url: Optional[str] = None
    output_video_key: Optional[str] = None
    video_url: Optional[str] = None
    download_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    error_message: Optional[str] = None
    segment_count: int = 1
    completed_segments: int = 0
    segments: List[SegmentResponse] = []
    created_at: str
    updated_at: str
    completed_at: Optional[str] = None


class EnhancePromptRequest(BaseModel):
    prompt: str = Field(..., min_length=3, max_length=1500)
    style: str = Field("cinematic")
    aspect_ratio: str = Field("9:16")


class EnhancePromptResponse(BaseModel):
    original_prompt: str
    enhanced_prompt: str
    used_external_llm: bool
    notice_he: str
